<?php
// iniciamos sesión
session_start();
if(!isset($_POST['filas'])) {
    // comprueba que se han mandado datos
    $_SESSION["mensaje"]="Debes introducir las filas y columnas";
    header("location:u03_a04_cp.php");
}
else{
    // comprobamos que los datos no están vacíos
    if(empty($_POST['filas']) ||
       empty($_POST['columnas']) ||
       empty($_POST['fila']) ||
       empty($_POST['columna'])) {
           $_SESSION['mensaje']="Debes rellenar todos los datos";
           header("location:u03_a04_cp.php");
       }
    else {
        // todo correcto, leemos todos los datos del formulario
        $filas=strip_tags($_POST['filas']);
        $columnas=strip_tags($_POST['columnas']);
        $fila=strip_tags($_POST['fila']);
        $columna=strip_tags($_POST['columna']);
        // creamos la tabla vacía con la cantidad de filas
        // y columnas indicada por el usuario
        $tabla=array();
        for($i=0;$i<$filas;$i++) {
         for($j=0;$j<$columnas;$j++) {
            $tabla[$i][$j]=($i+1)*($j+1);
         }
        }
        
        // finalmente, dibujamos la tabla
        echo "<table style='border:3px solid blue;border-collapse:collapse'>";
        for($i=0;$i<$filas;$i++) {
            echo "<tr>";
            for($j=0;$j<$columnas;$j++) {
                echo "<td style='border:3px solid blue;width:30px;height:30px;'>";
                echo $tabla[$i][$j];
                echo "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
        echo "<br/>";
        echo "<h4>En la fila $fila columna $columna tenemos el valor: ";
        echo $tabla[$fila-1][$columna-1];
        echo "</h4>";
    }
}
?>
