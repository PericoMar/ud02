<?php
// config.php
$servername = "localhost";
$username = "user_dwes";
$password = "userUSER2";
$dbname = "dwes";
