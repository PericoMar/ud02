<?php
// index.php
include_once('CONTROLADOR/controlador.php');
?>
